import { useMemo, useState } from 'react'
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react'
import type { BlockItem } from '../views/practice/store'
import ActionSheet from './ActionSheet'
import { LongPressRow } from './ui'

export type KanbanCol = 'plan' | 'work' | 'done'

// плоская карточка доски: пункт блока или пункт чек-листа
export interface KanbanEntry {
  blockId: string
  listId?: string
  item: BlockItem
  badge: string
  color: string
}

export interface KanbanBlockOpt {
  id: string
  title: string
}

const COLS: { id: KanbanCol; title: string; color: string }[] = [
  { id: 'plan', title: 'План', color: 'var(--accent)' },
  { id: 'work', title: 'В работе', color: '#e8963c' },
  { id: 'done', title: 'Готово', color: 'var(--done)' },
]

export const colOf = (it: BlockItem): KanbanCol =>
  it.done ? 'done' : it.status === 'work' ? 'work' : 'plan'

const keyOf = (e: KanbanEntry) => `${e.blockId}:${e.listId ?? ''}:${e.item.id}`

// доска из трёх колонок: План / В работе / Готово.
// Перенос — стрелками на карточке, long-press — переименовать/удалить,
// «+» в «Плане» — новый пункт в выбранном блоке.
export default function KanbanBoard({
  entries,
  blocks,
  readOnly,
  onMove,
  onRename,
  onDelete,
  onAdd,
  checklistBlocks = [],
  onAddChecklist,
}: {
  entries: KanbanEntry[]
  blocks: KanbanBlockOpt[] // блоки, куда можно добавлять пункты (allow.items)
  readOnly: boolean
  onMove: (e: KanbanEntry, col: KanbanCol) => void
  onRename: (e: KanbanEntry, text: string) => void
  onDelete: (e: KanbanEntry) => void
  onAdd: (blockId: string) => string // возвращает id нового пункта
  checklistBlocks?: KanbanBlockOpt[] // блоки, куда можно добавлять чек-листы
  onAddChecklist?: (blockId: string) => void
}) {
  const [editKey, setEditKey] = useState<string | null>(null)
  const [sheet, setSheet] = useState<KanbanEntry | null>(null)
  const [picker, setPicker] = useState(false)

  const byCol = useMemo(() => {
    const m: Record<KanbanCol, KanbanEntry[]> = { plan: [], work: [], done: [] }
    for (const e of entries) {
      // пустые пункты-заглушки не показываем, кроме редактируемого прямо сейчас
      if (!e.item.text.trim() && keyOf(e) !== editKey) continue
      m[colOf(e.item)].push(e)
    }
    return m
  }, [entries, editKey])

  const addItem = (blockId: string) => {
    const id = onAdd(blockId)
    setEditKey(`${blockId}::${id}`)
  }

  return (
    <section
      className="rounded-2xl p-3 mb-3"
      style={{ background: 'var(--surface)', border: '1px solid var(--line)' }}
    >
      <h2
        className="px-1 mb-3"
        style={{ fontFamily: 'var(--font-body)', fontSize: 15, fontWeight: 600, color: 'var(--light)' }}
      >
        Канбан
      </h2>
      <div className="grid grid-cols-3 gap-2">
        {COLS.map((col) => {
          const list = byCol[col.id]
          return (
            <div key={col.id} className="min-w-0">
              <div
                className="mb-2 pb-1 px-0.5 flex items-baseline justify-between"
                style={{ borderBottom: `2px solid ${col.color}`, position: 'sticky', top: 0, background: 'var(--surface)', zIndex: 1 }}
              >
                <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.04em', color: col.color }}>
                  {col.title.toUpperCase()}
                </span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--muted)' }}>
                  {list.length}
                </span>
              </div>
              <div style={{ maxHeight: '52dvh', overflowY: 'auto' }}>
              {list.map((e) => {
                const k = keyOf(e)
                const done = col.id === 'done'
                const editing = editKey === k && !readOnly
                return (
                  <LongPressRow
                    key={k}
                    disabled={readOnly}
                    onLongPress={() => setSheet(e)}
                    onClick={() => {}}
                    className="rounded-xl p-2 mb-2 text-left w-full"
                    style={{ background: 'var(--surface-2)', border: '1px solid var(--line)' }}
                  >
                    <span
                      className="inline-block max-w-full truncate rounded-md px-1.5 py-0.5 mb-1"
                      style={{ fontSize: 9, fontWeight: 600, color: 'var(--on-fill)', background: e.color }}
                    >
                      {e.badge}
                    </span>
                    {editing ? (
                      <input
                        ref={(el) => el?.focus()}
                        value={e.item.text}
                        onChange={(ev) => onRename(e, ev.target.value)}
                        onBlur={() => setEditKey(null)}
                        onKeyDown={(ev) => (ev.key === 'Enter' || ev.key === 'Escape') && setEditKey(null)}
                        onClick={(ev) => ev.stopPropagation()}
                        placeholder="Пункт…"
                        className="block w-full min-w-0 bg-transparent outline-none"
                        style={{ fontSize: 12, color: 'var(--light)', borderBottom: '1px solid var(--accent)' }}
                      />
                    ) : (
                      <span
                        className="block"
                        style={{
                          fontSize: 12,
                          lineHeight: 1.35,
                          color: done ? 'var(--muted)' : 'var(--light)',
                          textDecoration: done ? 'line-through' : 'none',
                          textDecorationColor: 'var(--line-strong)',
                          wordBreak: 'break-word',
                        }}
                      >
                        {e.item.text || '…'}
                      </span>
                    )}
                    {!readOnly && (
                      <div className="flex items-center justify-between mt-1.5">
                        {col.id !== 'plan' ? (
                          <button
                            onClick={(ev) => {
                              ev.stopPropagation()
                              onMove(e, col.id === 'done' ? 'work' : 'plan')
                            }}
                            onTouchStart={(ev) => ev.stopPropagation()}
                            className="p-0.5 -ml-0.5"
                            title={col.id === 'done' ? 'Вернуть в работу' : 'Вернуть в план'}
                          >
                            <ChevronLeft size={14} strokeWidth={2} style={{ color: 'var(--muted)' }} />
                          </button>
                        ) : (
                          <span />
                        )}
                        {col.id !== 'done' ? (
                          <button
                            onClick={(ev) => {
                              ev.stopPropagation()
                              onMove(e, col.id === 'plan' ? 'work' : 'done')
                            }}
                            onTouchStart={(ev) => ev.stopPropagation()}
                            className="p-0.5 -mr-0.5"
                            title={col.id === 'plan' ? 'В работу' : 'Готово'}
                          >
                            <ChevronRight size={14} strokeWidth={2} style={{ color: col.color }} />
                          </button>
                        ) : (
                          <span />
                        )}
                      </div>
                    )}
                  </LongPressRow>
                )
              })}
              </div>
              {!readOnly && col.id === 'plan' && (blocks.length > 0 || checklistBlocks.length > 0) && (
                <button
                  onClick={() =>
                    blocks.length === 1 && checklistBlocks.length === 0 ? addItem(blocks[0].id) : setPicker(true)
                  }
                  className="w-full rounded-xl border border-dashed px-2 py-2 flex items-center justify-center gap-1"
                  style={{ borderColor: 'var(--line-strong)', color: 'var(--muted)', fontSize: 11 }}
                >
                  <Plus size={12} strokeWidth={1.8} /> добавить
                </button>
              )}
              {list.length === 0 && col.id !== 'plan' && (
                <p className="text-center py-2" style={{ fontSize: 10, color: 'var(--muted)' }}>
                  пусто
                </p>
              )}
            </div>
          )
        })}
      </div>

      {/* long-press по карточке */}
      {sheet && (
        <ActionSheet
          title={sheet.item.text || 'Пункт'}
          onClose={() => setSheet(null)}
          onRename={() => setEditKey(keyOf(sheet))}
          onDelete={() => onDelete(sheet)}
        />
      )}

      {/* выбор блока для нового пункта */}
      {picker && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0" style={{ background: 'rgba(0,0,0,0.6)' }} onClick={() => setPicker(false)} />
          <div
            className="absolute inset-x-0 bottom-0 rounded-t-2xl p-4 fadein"
            style={{ background: 'var(--surface)', border: '1px solid var(--line)' }}
          >
            <div className="grid place-items-center pb-3">
              <span className="w-10 h-1 rounded-full" style={{ background: 'var(--line-strong)' }} />
            </div>
            <h2 className="mb-2" style={{ fontSize: 15, fontWeight: 600, color: 'var(--light)' }}>
              В какой блок добавить?
            </h2>
            {blocks.length > 0 && (
              <p className="px-1 pb-1" style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                Пункт
              </p>
            )}
            {blocks.map((b) => (
              <button
                key={b.id}
                onClick={() => {
                  setPicker(false)
                  addItem(b.id)
                }}
                className="w-full text-left rounded-xl px-3 py-3 mb-1"
                style={{ background: 'var(--surface-2)', color: 'var(--light)', fontSize: 14 }}
              >
                {b.title}
              </button>
            ))}
            {checklistBlocks.length > 0 && onAddChecklist && (
              <p className="px-1 pt-2 pb-1" style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                Чек-лист (новый или из записей)
              </p>
            )}
            {onAddChecklist &&
              checklistBlocks.map((b) => (
                <button
                  key={b.id}
                  onClick={() => {
                    setPicker(false)
                    onAddChecklist(b.id)
                  }}
                  className="w-full text-left rounded-xl px-3 py-3 mb-1"
                  style={{ background: 'var(--surface-2)', color: 'var(--light)', fontSize: 14 }}
                >
                  {b.title}
                </button>
              ))}
            <button
              onClick={() => setPicker(false)}
              className="mt-2 w-full py-2.5 rounded-xl"
              style={{ border: '1px solid var(--line-strong)', color: 'var(--muted)', fontSize: 13 }}
            >
              Отмена
            </button>
          </div>
        </div>
      )}
    </section>
  )
}
