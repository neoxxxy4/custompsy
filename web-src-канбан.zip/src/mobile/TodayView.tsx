import { useMemo, useRef, useState, type ReactNode } from 'react'
import {
  ChevronDown,
  CircleCheck,
  Clock,
  GripVertical,
  ListTodo,
  MoreHorizontal,
  Plus,
  SlidersHorizontal,
  Target,
} from 'lucide-react'
import {
  type BlockDef,
  type BlockItem,
  type BlockList,
  type ListRecord,
  type TodayData,
  moveItem,
  seedBlockDefs,
  seedTodayData,
  uid,
  useLS,
} from '../views/practice/store'
import { WD } from '../lib/dayStats'
import ProgressRing from './ProgressRing'
import ActionSheet from './ActionSheet'
import PickListSheet from './PickListSheet'
import KanbanBoard, { type KanbanCol, type KanbanEntry } from './KanbanBoard'
import BlockMenu from './BlockMenu'
import { useDragList } from './useDragList'
import { LongPressRow, MCheck, ScreenHeader } from './ui'
import { MO_FULL, useToast } from './utils'

type SheetTarget = { kind: 'item'; blockId: string; itemId: string; title: string }

type EditItem = { blockId: string; itemId: string; field: 'time' | 'text' }

const EMPTY_BLOCK: TodayData[string] = { items: [], lists: [] }

// цвета и иконки колец дашборда — цикл по четырём существующим
const RING_COLORS = ['var(--ring-goals)', 'var(--ring-schedule)', 'var(--ring-checklists)', 'var(--ring-tasks)']
const RING_ICONS = [Target, Clock, CircleCheck, ListTodo]

const fmtKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`

export default function TodayView() {
  const [offset, setOffset] = useState(0)
  const viewDate = useMemo(() => {
    const d = new Date()
    d.setDate(d.getDate() + offset)
    return d
  }, [offset])
  const dateKey = fmtKey(viewDate)
  const wdName = WD[viewDate.getDay()]
  const readOnly = offset === -1

  const [defs, setDefs] = useLS<BlockDef[]>('aod2-today-blocks', seedBlockDefs())
  const [listrecs] = useLS<ListRecord[]>('aod2-listrecs', [])
  // readOnly-день (вчера): мигрируем только то, что было в legacy, без дефолтов
  const [data, setData] = useLS<TodayData>(`aod2-today-data-${dateKey}`, seedTodayData(dateKey, wdName, readOnly))

  const [open, setOpen] = useState<Record<string, boolean>>({})
  const [editItem, setEditItem] = useState<EditItem | null>(null)
  const [sheet, setSheet] = useState<SheetTarget | null>(null)
  const [pickList, setPickList] = useState<{ def: BlockDef; kind: BlockList['kind'] } | null>(null)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [menuBlockId, setMenuBlockId] = useState<string | null>(null)
  const [editDefId, setEditDefId] = useState<string | null>(null)
  const [flash, setFlash] = useState<string | null>(null)
  const toast = useToast()

  const cardEls = useRef<Record<string, HTMLElement | null>>({})
  const anyDrag = useRef<Record<string, boolean>>({})
  const swipe = useRef<{ x: number; y: number } | null>(null)

  // ─── данные блоков ───
  const blockData = (id: string) => data[id] ?? EMPTY_BLOCK

  // прогресс блока = пункты + пункты чек-листов; нумерованные списки не считаются
  const blockStat = (id: string) => {
    const b = blockData(id)
    const all = [...b.items, ...b.lists.filter((l) => l.kind === 'checklist').flatMap((l) => l.items)]
    return { done: all.filter((i) => i.done).length, total: all.length }
  }

  const patchBlockData = (blockId: string, fn: (b: TodayData[string]) => TodayData[string]) =>
    setData((d) => ({ ...d, [blockId]: fn(d[blockId] ?? { items: [], lists: [] }) }))
  const patchItem = (blockId: string, itemId: string, patch: Partial<BlockItem>) =>
    patchBlockData(blockId, (b) => ({ ...b, items: b.items.map((x) => (x.id === itemId ? { ...x, ...patch } : x)) }))
  const patchList = (blockId: string, listId: string, fn: (l: BlockList) => BlockList) =>
    patchBlockData(blockId, (b) => ({ ...b, lists: b.lists.map((l) => (l.id === listId ? fn(l) : l)) }))

  const addItem = (def: BlockDef) => {
    const it: BlockItem = { id: uid(), text: '', done: false, ...(def.withTime ? { time: '12:00' } : {}) }
    patchBlockData(def.id, (b) => ({ ...b, items: [...b.items, it] }))
    setEditItem({ blockId: def.id, itemId: it.id, field: 'text' })
    openBlock(def.id)
  }
  // новый пустой под-список (чек-лист сразу с одним пунктом — виден на доске)
  const addList = (def: BlockDef, kind: BlockList['kind']) => {
    const lst: BlockList = {
      id: uid(),
      kind,
      title: '',
      items: kind === 'checklist' ? [{ id: uid(), text: '', done: false }] : [],
    }
    patchBlockData(def.id, (b) => ({ ...b, lists: [...b.lists, lst] }))
  }

  // вставка копии сохранённого чек-листа из «Записей»: пункты свежие (done сброшен), id новые
  const insertFromRecord = (def: BlockDef, rec: ListRecord) => {
    const lst: BlockList = {
      id: uid(),
      kind: rec.kind,
      title: rec.title,
      items: rec.items.map((it) => ({ id: uid(), text: it.text, done: false })),
    }
    patchBlockData(def.id, (b) => ({ ...b, lists: [...b.lists, lst] }))
  }

  // ─── настройка блоков (глобально, не зависит от дня) ───
  const patchDef = (id: string, patch: Partial<BlockDef>) =>
    setDefs((ds) => ds.map((d) => (d.id === id ? { ...d, ...patch } : d)))
  const deleteDef = (id: string) => setDefs((ds) => ds.filter((d) => d.id !== id))
  const addBlockDef = () => {
    const def: BlockDef = {
      id: uid(),
      title: '',
      withTime: false,
      inDashboard: true,
      allow: { items: true, checklists: false, lists: false },
    }
    setDefs((ds) => [...ds, def])
    setEditDefId(def.id)
  }

  const jumpTo = (id: string) => {
    // блоки без времени живут на канбан-доске — скроллим к ней
    const target = defs.find((d) => d.id === id)?.withTime ? id : 'kanban'
    if (target !== 'kanban') setOpen((o) => ({ ...o, [target]: true }))
    cardEls.current[target]?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    setFlash(target)
    window.setTimeout(() => setFlash((f) => (f === target ? null : f)), 600)
  }

  // ─── свайпы: влево — Завтра, вправо — Вчера ───
  const changeOffset = (next: number) => {
    setOffset(Math.max(-1, Math.min(1, next)))
    setSheet(null)
    setEditItem(null)
    setFlash(null)
  }
  const onTouchStart = (e: React.TouchEvent) => {
    const t = e.touches[0]
    swipe.current = { x: t.clientX, y: t.clientY }
  }
  const onTouchEnd = (e: React.TouchEvent) => {
    const s = swipe.current
    swipe.current = null
    if (!s) return
    if (blocksDrag.dragging || Object.values(anyDrag.current).some(Boolean)) return
    const t = e.changedTouches[0]
    const dx = t.clientX - s.x
    const dy = t.clientY - s.y
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy)) changeOffset(offset + (dx < 0 ? 1 : -1))
  }

  const openBlock = (b: string) => setOpen((o) => ({ ...o, [b]: true }))
  const toggleBlock = (b: string) => setOpen((o) => ({ ...o, [b]: !o[b] }))

  // ─── drag-сортировка блоков в шторке «Блоки экрана» ───
  const blocksDrag = useDragList({
    onReorder: (from, to) => setDefs((ds) => moveItem(ds, from, to)),
    onLongPress: () => {},
  })

  // ─── action-sheet по long-press ───
  const sheetRename = () => {
    const t = sheet
    if (!t) return
    setEditItem({ blockId: t.blockId, itemId: t.itemId, field: 'text' })
    openBlock(t.blockId)
  }
  const sheetDelete = () => {
    const t = sheet
    if (!t) return
    patchBlockData(t.blockId, (b) => ({ ...b, items: b.items.filter((x) => x.id !== t.itemId) }))
  }

  const dashBlocks = defs.filter((d) => d.inDashboard)
  const menuDef = defs.find((d) => d.id === menuBlockId) ?? null

  // ─── канбан: расписание (блоки со временем) остаётся списком,
  // пункты остальных блоков (+ пункты чек-листов) уходят на доску ───
  const schedDefs = defs.filter((d) => d.withTime)
  const kanbanDefs = defs.filter((d) => !d.withTime)
  const kanbanEntries: KanbanEntry[] = kanbanDefs.flatMap((def) => {
    const bd = blockData(def.id)
    const color = RING_COLORS[defs.indexOf(def) % RING_COLORS.length]
    const direct = bd.items.map((item) => ({
      blockId: def.id,
      item,
      badge: def.title || 'Блок',
      color,
    }))
    const fromLists = bd.lists
      .filter((l) => l.kind === 'checklist')
      .flatMap((l) =>
        l.items.map((item) => ({
          blockId: def.id,
          listId: l.id,
          item,
          badge: l.title || def.title || 'Чек-лист',
          color,
        })),
      )
    return [...direct, ...fromLists]
  })

  const patchKanbanItem = (e: KanbanEntry, patch: Partial<BlockItem>) => {
    if (e.listId)
      patchList(e.blockId, e.listId, (l) => ({
        ...l,
        items: l.items.map((x) => (x.id === e.item.id ? { ...x, ...patch } : x)),
      }))
    else patchItem(e.blockId, e.item.id, patch)
  }
  const moveKanban = (e: KanbanEntry, col: KanbanCol) =>
    patchKanbanItem(
      e,
      col === 'done'
        ? { done: true, status: undefined }
        : col === 'work'
          ? { done: false, status: 'work' }
          : { done: false, status: 'plan' },
    )
  const deleteKanban = (e: KanbanEntry) => {
    if (e.listId)
      patchList(e.blockId, e.listId, (l) => ({ ...l, items: l.items.filter((x) => x.id !== e.item.id) }))
    else patchBlockData(e.blockId, (b) => ({ ...b, items: b.items.filter((x) => x.id !== e.item.id) }))
  }
  // добавление пункта из колонки «План» — возвращает id для inline-редактирования
  const addKanbanItem = (blockId: string): string => {
    const it: BlockItem = { id: uid(), text: '', done: false, status: 'plan' }
    patchBlockData(blockId, (b) => ({ ...b, items: [...b.items, it] }))
    return it.id
  }

  const title = offset === -1 ? 'Вчера' : offset === 1 ? 'Завтра' : 'Сегодня'
  const sub = `${viewDate.getDate()} ${MO_FULL[viewDate.getMonth()]}${readOnly ? ' · только чтение' : ''}`

  return (
    <div className="px-4 pt-5 pb-28" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      <ScreenHeader
        title={title}
        sub={sub}
        right={
          <button onClick={() => setSettingsOpen(true)} title="Блоки экрана" className="p-1">
            <SlidersHorizontal size={20} strokeWidth={1.7} style={{ color: 'var(--muted)' }} />
          </button>
        }
      />

      <div key={dateKey} className="fadein">
        {/* блоки расписания (со временем) — как раньше, списком */}
        {schedDefs.map((def) => {
          const bd = blockData(def.id)
          const st = blockStat(def.id)
          return (
            <div className="mb-3" key={def.id} ref={(el) => { cardEls.current[def.id] = el }}>
              <BlockShell
                title={def.title || 'Блок'}
                count={st.total ? `${st.done}/${st.total}` : '—'}
                expanded={!!open[def.id]}
                flash={flash === def.id}
                readOnly={readOnly}
                progress={st.total ? st.done / st.total : 0}
                onToggle={() => toggleBlock(def.id)}
                onAdd={readOnly || !def.allow.items ? undefined : () => addItem(def)}
                onMenu={readOnly ? undefined : () => setMenuBlockId(def.id)}
              >
                {bd.items.length === 0 && <EmptyDash />}
                {bd.items.length > 0 && (
                  <ItemsSection
                    blockId={def.id}
                    withTime={def.withTime}
                    items={bd.items}
                    readOnly={readOnly}
                    editItem={editItem}
                    onEditItem={setEditItem}
                    onPatchItem={(itemId, patch) => patchItem(def.id, itemId, patch)}
                    onReorder={(from, to) =>
                      patchBlockData(def.id, (b) => ({ ...b, items: moveItem(b.items, from, to) }))
                    }
                    onLongPressItem={(itemId, t) => setSheet({ kind: 'item', blockId: def.id, itemId, title: t })}
                    anyDrag={anyDrag}
                  />
                )}
                {!readOnly && def.allow.items && (
                  <AddRow label="добавить событие" onClick={() => addItem(def)} />
                )}
              </BlockShell>
            </div>
          )
        })}

        {/* канбан по всем остальным блокам */}
        <div ref={(el) => { cardEls.current['kanban'] = el }}>
          <KanbanBoard
            entries={kanbanEntries}
            blocks={kanbanDefs.filter((d) => d.allow.items).map((d) => ({ id: d.id, title: d.title || 'Блок' }))}
            readOnly={readOnly}
            onMove={moveKanban}
            onRename={(e, text) => patchKanbanItem(e, { text })}
            onDelete={deleteKanban}
            onAdd={addKanbanItem}
            checklistBlocks={kanbanDefs
              .filter((d) => d.allow.checklists)
              .map((d) => ({ id: d.id, title: d.title || 'Блок' }))}
            onAddChecklist={(blockId) => {
              const def = defs.find((d) => d.id === blockId)
              if (def) setPickList({ def, kind: 'checklist' })
            }}
          />
        </div>

        {/* прогресс дня — кольца по блокам с «Показывать в дашборде» */}
        {dashBlocks.length > 0 && (
          <section
            className="rounded-2xl p-4 mb-3"
            style={{ background: 'var(--surface)', border: '1px solid var(--line)' }}
          >
            <h2 className="mb-3" style={{ fontFamily: 'var(--font-body)', fontSize: 15, fontWeight: 600, color: 'var(--light)' }}>
              Прогресс дня
            </h2>
            <div className="flex justify-between px-1">
              {dashBlocks.map((def, di) => {
                const st = blockStat(def.id)
                const pct = st.total ? st.done / st.total : 0
                const color = RING_COLORS[di % RING_COLORS.length]
                const Icon = RING_ICONS[di % RING_ICONS.length]
                return (
                  <button key={def.id} onClick={() => jumpTo(def.id)} className="flex flex-col items-center gap-1">
                    <span className="relative">
                      <ProgressRing pct={pct} color={color} size={64} />
                      <span
                        className="absolute inset-0 grid place-items-center"
                        style={{ fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 700, color: 'var(--light)' }}
                      >
                        {Math.round(pct * 100)}%
                      </span>
                    </span>
                    <Icon size={14} strokeWidth={1.8} style={{ color }} />
                    <span className="max-w-[72px] truncate" style={{ fontSize: 11, color: 'var(--text-2)' }}>
                      {def.title || 'Блок'}
                    </span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--muted)' }}>
                      {st.total ? `${st.done}/${st.total}` : '—'}
                    </span>
                  </button>
                )
              })}
            </div>
          </section>
        )}

      </div>

      {/* выбор: новый под-список или готовый из «Записей» */}
      {pickList && (
        <PickListSheet
          kind={pickList.kind}
          records={listrecs.filter((r) => r.kind === pickList.kind)}
          onNew={() => addList(pickList.def, pickList.kind)}
          onPick={(rec) => insertFromRecord(pickList.def, rec)}
          onClose={() => setPickList(null)}
        />
      )}

      {/* action-sheet по long-press */}
      {sheet && (
        <ActionSheet
          title={sheet.title}
          onClose={() => setSheet(null)}
          onRename={sheetRename}
          onDelete={sheetDelete}
        />
      )}

      {/* меню блока (из шторки настроек и из шапки развёрнутого блока) */}
      {menuDef && (
        <BlockMenu
          def={menuDef}
          onClose={() => setMenuBlockId(null)}
          onPatch={(patch) => patchDef(menuDef.id, patch)}
          onDelete={() => deleteDef(menuDef.id)}
        />
      )}

      {/* шторка «Блоки экрана»: переименование, меню, drag-порядок, добавление */}
      {settingsOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0" style={{ background: 'rgba(0,0,0,0.6)' }} onClick={() => setSettingsOpen(false)} />
          <div
            className="absolute inset-x-0 bottom-0 rounded-t-2xl p-4 overflow-y-auto fadein"
            style={{ background: 'var(--surface)', border: '1px solid var(--line)', maxHeight: '80dvh' }}
          >
            <div className="grid place-items-center pb-3">
              <span className="w-10 h-1 rounded-full" style={{ background: 'var(--line-strong)' }} />
            </div>
            <h2 className="mb-2" style={{ fontFamily: 'var(--font-body)', fontSize: 15, fontWeight: 600, color: 'var(--light)' }}>
              Блоки экрана
            </h2>
            <div {...blocksDrag.containerProps}>
              {defs.map((def, i) => {
                const st = blockStat(def.id)
                return (
                  <div
                    key={def.id}
                    {...blocksDrag.bindRow(i)}
                    style={blocksDrag.rowStyle(i)}
                    className="no-select flex items-center gap-2.5 rounded-xl px-2 py-2.5"
                  >
                    <GripVertical size={16} strokeWidth={1.8} className="flex-none" style={{ color: 'var(--muted)' }} />
                    {editDefId === def.id ? (
                      <input
                        ref={(el) => el?.focus()}
                        value={def.title}
                        onChange={(e) => patchDef(def.id, { title: e.target.value })}
                        onBlur={() => setEditDefId(null)}
                        onKeyDown={(e) => (e.key === 'Enter' || e.key === 'Escape') && setEditDefId(null)}
                        placeholder="Название блока"
                        className="flex-1 min-w-0 bg-transparent outline-none"
                        style={{ fontSize: 14, color: 'var(--light)', borderBottom: '1px solid var(--accent)' }}
                      />
                    ) : (
                      <span className="flex-1 min-w-0 truncate" style={{ fontSize: 14, fontWeight: 500, color: 'var(--light)' }}>
                        {def.title || 'Без названия'}
                      </span>
                    )}
                    <span className="flex-none" style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)' }}>
                      {st.total} пунктов
                    </span>
                    <button onClick={() => setMenuBlockId(def.id)} className="flex-none p-1" title="Действия блока">
                      <MoreHorizontal size={18} strokeWidth={1.8} style={{ color: 'var(--muted)' }} />
                    </button>
                  </div>
                )
              })}
            </div>
            <AddRow label="Добавить блок" onClick={addBlockDef} />
            <button
              onClick={() => setSettingsOpen(false)}
              className="mt-3 w-full py-2.5 rounded-xl"
              style={{ border: '1px solid var(--line-strong)', color: 'var(--muted)', fontSize: 13 }}
            >
              Закрыть
            </button>
          </div>
        </div>
      )}

      {toast.node}
    </div>
  )
}

// пункты блока (цели/задачи/события): чекбокс (или время) + текст;
// тап по тексту НЕ открывает редактирование — только long-press → action-sheet;
// новая строка (после «добавить …») сразу в режиме инпута
function ItemsSection({
  blockId,
  withTime,
  items,
  readOnly,
  editItem,
  onEditItem,
  onPatchItem,
  onReorder,
  onLongPressItem,
  anyDrag,
}: {
  blockId: string
  withTime: boolean
  items: BlockItem[]
  readOnly: boolean
  editItem: EditItem | null
  onEditItem: (v: EditItem | null) => void
  onPatchItem: (itemId: string, patch: Partial<BlockItem>) => void
  onReorder: (from: number, to: number) => void
  onLongPressItem: (itemId: string, title: string) => void
  anyDrag: { current: Record<string, boolean> }
}) {
  const drag = useDragList({
    disabled: readOnly,
    onReorder,
    onLongPress: (i) => {
      const it = items[i]
      if (it) onLongPressItem(it.id, it.text || 'Пункт')
    },
  })
  anyDrag.current[`items:${blockId}`] = drag.dragging

  return (
    <div {...drag.containerProps}>
      {items.map((it, i) => {
        const editing = editItem?.blockId === blockId && editItem.itemId === it.id && !readOnly
        return (
          <div
            key={it.id}
            {...drag.bindRow(i)}
            style={drag.rowStyle(i)}
            className="no-select flex items-center gap-2.5 px-1 py-2"
            onBlur={(e) => {
              if (editing && !e.currentTarget.contains(e.relatedTarget as Node)) onEditItem(null)
            }}
          >
            {!withTime && (
              <button
                onClick={() => onPatchItem(it.id, { done: !it.done })}
                disabled={readOnly}
                className="flex-none disabled:cursor-default"
              >
                <MCheck done={it.done} color="var(--done)" />
              </button>
            )}
            {editing ? (
              <>
                {withTime && (
                  <input
                    ref={editItem?.field === 'time' ? (el) => el?.focus() : undefined}
                    value={it.time ?? ''}
                    onChange={(e) => onPatchItem(it.id, { time: e.target.value })}
                    onKeyDown={(e) => (e.key === 'Enter' || e.key === 'Escape') && onEditItem(null)}
                    className="w-[46px] flex-none bg-transparent outline-none"
                    style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--accent)', borderBottom: '1px solid var(--accent)' }}
                    title="Время (HH:MM)"
                  />
                )}
                <input
                  ref={editItem?.field !== 'time' ? (el) => el?.focus() : undefined}
                  value={it.text}
                  onChange={(e) => onPatchItem(it.id, { text: e.target.value })}
                  onKeyDown={(e) => (e.key === 'Enter' || e.key === 'Escape') && onEditItem(null)}
                  placeholder="Новый пункт…"
                  className="flex-1 min-w-0 bg-transparent outline-none"
                  style={{ fontSize: 14, color: 'var(--light)', borderBottom: '1px solid var(--accent)' }}
                />
              </>
            ) : (
              <>
                {withTime && (
                  <span
                    className="w-[46px] flex-none"
                    style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--accent)' }}
                  >
                    {it.time || '—'}
                  </span>
                )}
                <span
                  className="flex-1 min-w-0 truncate"
                  style={{
                    fontSize: 14,
                    color: it.done ? 'var(--muted)' : 'var(--text-2)',
                    textDecoration: it.done ? 'line-through' : 'none',
                    textDecorationColor: 'var(--line-strong)',
                  }}
                >
                  {it.text || <span style={{ color: 'var(--muted)' }}>Пункт…</span>}
                </span>
              </>
            )}
            {withTime && (
              <button
                onClick={() => onPatchItem(it.id, { done: !it.done })}
                disabled={readOnly}
                className="flex-none disabled:cursor-default"
                title="Отметить"
              >
                <MCheck done={it.done} color="var(--done)" />
              </button>
            )}
          </div>
        )
      })}
    </div>
  )
}


// сворачиваемый блок: заголовок (тап — свернуть, long-press — добавить пункт,
// «…» — меню блока) + прогресс-линия под заголовком + контент-аккордеон
function BlockShell({
  title,
  count,
  expanded,
  flash,
  readOnly,
  progress,
  onToggle,
  onAdd,
  onMenu,
  children,
}: {
  title: string
  count: string
  expanded: boolean
  flash?: boolean
  readOnly?: boolean
  progress: number
  onToggle: () => void
  onAdd?: () => void
  onMenu?: () => void
  children: ReactNode
}) {
  return (
    <section
      className="rounded-2xl"
      style={{
        background: 'var(--surface)',
        border: '1px solid var(--line)',
        transition: 'box-shadow .3s ease, border-color .3s ease',
        ...(flash ? { borderColor: 'var(--accent)', boxShadow: '0 0 0 1px var(--accent)' } : {}),
      }}
    >
      <LongPressRow
        disabled={readOnly || !onAdd}
        onLongPress={onAdd ?? (() => {})}
        onClick={onToggle}
        className="flex w-full items-center gap-2 px-4 pt-3.5 pb-2"
      >
        <span
          className="flex-1 text-left"
          style={{ fontFamily: 'var(--font-body)', fontSize: 15, fontWeight: 600, color: 'var(--light)' }}
        >
          {title}
        </span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)' }}>{count}</span>
        {!readOnly && expanded && onMenu && (
          <button
            onClick={(e) => {
              e.stopPropagation()
              onMenu()
            }}
            onTouchStart={(e) => e.stopPropagation()}
            onMouseDown={(e) => e.stopPropagation()}
            className="p-1 -mr-1"
            title="Действия блока"
          >
            <MoreHorizontal size={18} strokeWidth={1.8} style={{ color: 'var(--muted)' }} />
          </button>
        )}
        <ChevronDown
          size={16}
          strokeWidth={1.8}
          style={{ color: 'var(--muted)', transition: 'transform .2s', transform: expanded ? 'rotate(180deg)' : 'none' }}
        />
      </LongPressRow>
      {/* прогресс-линия блока — всегда, и в свёрнутом виде */}
      <div className="mx-4 mb-2 h-1 rounded-full overflow-hidden" style={{ background: 'var(--line)' }}>
        <span
          className="block h-full rounded-full"
          style={{ width: `${progress * 100}%`, background: 'var(--accent)', transition: 'width .35s ease' }}
        />
      </div>
      <div
        style={{
          display: 'grid',
          gridTemplateRows: expanded ? '1fr' : '0fr',
          transition: 'grid-template-rows .3s cubic-bezier(0.65,0,0.35,1)',
        }}
      >
        <div style={{ overflow: 'hidden' }}>
          <div className="px-3 pb-3">{children}</div>
        </div>
      </div>
    </section>
  )
}

function AddRow({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="mt-1 flex w-full items-center gap-2 rounded-xl border border-dashed px-3 py-2"
      style={{ borderColor: 'var(--line-strong)', color: 'var(--muted)', fontSize: 13 }}
    >
      <Plus size={14} strokeWidth={1.8} /> {label}
    </button>
  )
}

function EmptyDash() {
  return (
    <p className="py-3 text-center" style={{ fontSize: 13, color: 'var(--muted)' }}>
      —
    </p>
  )
}
