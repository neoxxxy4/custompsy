import { useState } from 'react'
import MobileBottomNav, { type MTab } from './MobileBottomNav'
import TodayView from './TodayView'
import RecordsView, { type FolderKey } from './RecordsView'
import BlogMobileView from './BlogMobileView'
import PathView from './PathView'
import SystemView from './SystemView'
import type { ThemeId } from '../lib/theme'

// мобильная оболочка (<1024px): 5 вкладок + нижнее меню
export default function MobileApp({ theme, onToggleTheme }: { theme: ThemeId; onToggleTheme: () => void }) {
  const [tab, setTab] = useState<MTab>('today')
  const [recordsFolder, setRecordsFolder] = useState<FolderKey>('all')

  const go = (t: MTab) => {
    setTab(t)
    window.scrollTo({ top: 0 })
  }

  return (
    <div className="min-h-screen relative z-10" style={{ color: 'var(--text)' }}>
      {tab === 'today' && <TodayView />}
      {tab === 'records' && (
        <RecordsView folder={recordsFolder} onFolder={setRecordsFolder} onHome={() => go('today')} />
      )}
      {tab === 'blog' && <BlogMobileView />}
      {tab === 'path' && <PathView />}
      {tab === 'system' && <SystemView theme={theme} onToggleTheme={onToggleTheme} />}
      <MobileBottomNav tab={tab} go={go} />
    </div>
  )
}
