import { useState, useCallback } from 'react'
import Dashboard from './views/Dashboard'
import GraphView from './views/GraphView'
import ChecklistsView from './views/ChecklistsView'
import BalanceView from './views/BalanceView'
import RoadmapView from './views/RoadmapView'
import PlanningView from './views/PlanningView'
import CalendarView from './views/CalendarView'
import { MODULES } from './data/system'

export type ViewId = 'hub' | 'graph' | 'checklists' | 'balance' | 'roadmap' | 'planning' | 'calendar'

const VIEW_TITLES: Record<ViewId, string> = {
  hub: 'Хаб',
  graph: 'Граф',
  checklists: 'Чек-листы',
  balance: 'Баланс',
  roadmap: 'Роадмапа',
  planning: 'Планирование',
  calendar: 'Календарь',
}

export default function App() {
  const [view, setView] = useState<ViewId>('hub')
  const [animKey, setAnimKey] = useState(0)

  const go = useCallback((v: ViewId) => {
    setView(v)
    setAnimKey((k) => k + 1)
    window.scrollTo({ top: 0 })
  }, [])

  return (
    <div className="min-h-screen relative" style={{ background: 'var(--bg)' }}>
      <div className="blueprint-bg" />
      <div className="vignette" />

      {/* floating header */}
      <header className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[calc(100%-24px)] max-w-5xl">
        <div className="glass rounded-md flex items-center gap-1 px-3 py-2">
          <button
            onClick={() => go('hub')}
            className="flex items-center gap-2.5 pr-3 mr-1"
            style={{ borderRight: '1px solid var(--line)' }}
          >
            <span
              className="grid place-items-center w-7 h-7 rounded-sm"
              style={{ background: 'var(--accent)', color: '#fff', fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600 }}
            >
              А
            </span>
            <span className="hidden sm:block leading-none">
              <span className="display block" style={{ fontSize: 13 }}>Архитектор</span>
              <span className="mono-label" style={{ fontSize: 8, letterSpacing: '0.22em' }}>осознанного доверия</span>
            </span>
          </button>
          <nav className="flex items-center overflow-x-auto flex-1" style={{ scrollbarWidth: 'none' }}>
            {MODULES.map((m) => (
              <button
                key={m.id}
                className={`nav-item ${view === m.id ? 'active' : ''}`}
                onClick={() => go(m.id as ViewId)}
              >
                {m.name}
              </button>
            ))}
          </nav>
          <span className="mono-label hidden md:block pl-3" style={{ borderLeft: '1px solid var(--line)' }}>
            v3.0
          </span>
        </div>
      </header>

      <main key={animKey} className="relative z-10 fadein">
        {view === 'hub' && <Dashboard go={go} />}
        {view === 'graph' && <GraphView />}
        {view === 'checklists' && <ChecklistsView />}
        {view === 'balance' && <BalanceView />}
        {view === 'roadmap' && <RoadmapView />}
        {view === 'planning' && <PlanningView />}
        {view === 'calendar' && <CalendarView />}
      </main>

      <footer className="relative z-10 max-w-5xl mx-auto px-6 pb-10 pt-4 flex flex-wrap gap-x-6 gap-y-2 items-center justify-between">
        <span className="mono-label">Понимание → Оптимизация → Управление → Гиперфокус</span>
        <span className="mono-label">{VIEW_TITLES[view]} · архитектура v3.0 «Проводник»</span>
      </footer>
    </div>
  )
}
