import { useEffect, useMemo, useState } from 'react'
import { CHECKLISTS } from '../data/system'

const todayKey = () => new Date().toISOString().slice(0, 10)

function loadState(): Record<string, boolean> {
  try {
    return JSON.parse(localStorage.getItem(`aod-checks-${todayKey()}`) || '{}')
  } catch {
    return {}
  }
}

function Ring({ pct, color, size = 54 }: { pct: number; color: string; size?: number }) {
  const r = (size - 8) / 2
  const c = 2 * Math.PI * r
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--line)" strokeWidth="3" />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke={color}
        strokeWidth="3"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={c * (1 - pct)}
        style={{ transition: 'stroke-dashoffset .5s cubic-bezier(0.65,0,0.35,1)' }}
      />
    </svg>
  )
}

export default function ChecklistsView() {
  const [checks, setChecks] = useState<Record<string, boolean>>(loadState)

  useEffect(() => {
    localStorage.setItem(`aod-checks-${todayKey()}`, JSON.stringify(checks))
  }, [checks])

  const toggle = (id: string) => setChecks((s) => ({ ...s, [id]: !s[id] }))

  const total = CHECKLISTS.reduce((n, l) => n + l.items.length, 0)
  const done = Object.values(checks).filter(Boolean).length
  const dayPct = total ? done / total : 0

  const listPct = useMemo(
    () =>
      Object.fromEntries(
        CHECKLISTS.map((l) => [
          l.id,
          l.items.filter((it) => checks[`${l.id}:${it.id}`]).length / l.items.length,
        ])
      ),
    [checks]
  )

  return (
    <div className="max-w-5xl mx-auto px-6 pt-28 pb-10">
      <div className="rise flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="mono-label mb-2">Модуль 02 · сброс каждый день</p>
          <h2 className="display" style={{ fontSize: 'clamp(36px, 5vw, 64px)' }}>Чек-листы</h2>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Ring pct={dayPct} color="var(--accent)" size={72} />
            <span
              className="absolute inset-0 grid place-items-center"
              style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--light)' }}
            >
              {Math.round(dayPct * 100)}%
            </span>
          </div>
          <div>
            <p className="mono-label">Прогресс дня</p>
            <p className="display" style={{ fontSize: 24 }}>{done} / {total}</p>
          </div>
          <button
            onClick={() => setChecks({})}
            className="mono-label-bright px-3 py-2 rounded-sm glass hover:opacity-80 transition-opacity"
          >
            Сброс
          </button>
        </div>
      </div>

      <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-3">
        {CHECKLISTS.map((list, li) => (
          <section
            key={list.id}
            className="rise panel rounded-md p-6"
            style={{ animationDelay: `${li * 80}ms`, ...(li === 0 ? { gridRow: 'span 1' } : {}) }}
          >
            <header className="flex items-center justify-between gap-4 mb-2">
              <div>
                <div className="flex items-center gap-2">
                  <span className="tag-dot" style={{ background: list.color }} />
                  <h3 className="display" style={{ fontSize: 22 }}>{list.title}</h3>
                </div>
                <p className="mono-label mt-1">{list.time}</p>
              </div>
              <Ring pct={listPct[list.id] ?? 0} color={list.color} size={44} />
            </header>
            <div>
              {list.items.map((it) => {
                const key = `${list.id}:${it.id}`
                const isDone = !!checks[key]
                return (
                  <div
                    key={it.id}
                    className={`check-row ${isDone ? 'done' : ''}`}
                    style={{ ['--row-color' as string]: list.color }}
                    onClick={() => toggle(key)}
                  >
                    <span className="box">
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                        <path d="M1.5 5.5L4 8L8.5 2" stroke="#050100" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                    </span>
                    <span>
                      <span className="label block text-[13.5px] leading-snug" style={{ color: 'var(--light)' }}>
                        {it.text}
                      </span>
                      {it.hint && (
                        <span className="block mt-0.5 text-[11.5px]" style={{ color: 'var(--muted)' }}>
                          {it.hint}
                        </span>
                      )}
                    </span>
                  </div>
                )
              })}
            </div>
          </section>
        ))}

        <aside className="rise panel rounded-md p-6 flex flex-col justify-between" style={{ animationDelay: '400ms' }}>
          <div>
            <p className="mono-label mb-3">Принцип</p>
            <p className="display" style={{ fontSize: 24, lineHeight: 1.2 }}>
              Порядок — это заранее принятые решения
            </p>
            <p className="mt-4 text-[13px] leading-relaxed" style={{ color: 'var(--text)' }}>
              Чек-лист разгружает рабочую память: ОЗУ держит 7±2 объекта, всё остальное —
              во внешнюю память. Отметки хранятся в этом браузере и обнуляются каждое утро.
            </p>
          </div>
          <p className="mono-label mt-6">«Самодисциплина — не клетка, а стартовая площадка»</p>
        </aside>
      </div>
    </div>
  )
}
