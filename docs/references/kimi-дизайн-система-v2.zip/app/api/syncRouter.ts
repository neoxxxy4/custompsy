import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getKv, setKv, listKv } from "./queries/kv";

// Синхронизация состояния модулей: фронтенд читает/пишет
// документы по строковым ключам, сервер хранит их в MySQL.
export const syncRouter = createRouter({
  get: publicQuery
    .input(z.object({ key: z.string().min(1).max(191) }))
    .query(async ({ input }) => {
      const row = await getKv(input.key);
      return { value: row ? (row.value as unknown) : null };
    }),

  set: publicQuery
    .input(z.object({ key: z.string().min(1).max(191), value: z.unknown() }))
    .mutation(async ({ input }) => {
      await setKv(input.key, input.value);
      return { ok: true };
    }),

  all: publicQuery.query(async () => {
    const rows = await listKv();
    return rows.map((r) => ({ key: r.key, value: r.value as unknown }));
  }),
});
