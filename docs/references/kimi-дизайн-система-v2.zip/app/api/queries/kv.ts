import { getDb } from "./connection";
import { kvStore } from "@db/schema";
import { eq } from "drizzle-orm";

export async function getKv(key: string) {
  const row = await getDb().query.kvStore.findFirst({
    where: eq(kvStore.key, key),
  });
  return row ?? null;
}

export async function setKv(key: string, value: unknown) {
  await getDb()
    .insert(kvStore)
    .values({ key, value })
    .onDuplicateKeyUpdate({ set: { value, updatedAt: new Date() } });
}

export async function listKv() {
  return getDb().select().from(kvStore);
}
