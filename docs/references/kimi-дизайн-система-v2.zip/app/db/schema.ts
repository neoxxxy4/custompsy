import {
  mysqlTable,
  varchar,
  json,
  timestamp,
  index,
} from "drizzle-orm/mysql-core";

// Универсальное хранилище документов системы.
// Каждый модуль хранит свои данные под строковым ключом
// (например: aod2-day-2026-09-10, aod2-notes, aod-balance).
// Такая форма — фундамент под будущий реестр модулей:
// новые модули не требуют новых таблиц.
export const kvStore = mysqlTable(
  "kv_store",
  {
    key: varchar("key", { length: 191 }).primaryKey(),
    value: json("value").notNull(),
    updatedAt: timestamp("updated_at")
      .notNull()
      .defaultNow()
      .onUpdateNow(),
  },
  (table) => ({
    updatedIdx: index("updated_idx").on(table.updatedAt),
  }),
);

export type KvEntry = typeof kvStore.$inferSelect;
