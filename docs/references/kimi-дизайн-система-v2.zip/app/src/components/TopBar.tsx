import { useEffect, useMemo, useRef, useState } from 'react'
import type { ViewId } from '../App'
import { WEEK_TEMPLATE, CAL_EVENTS, type CalEvent } from '../data/system'
import { type DayInstance, todayKey } from '../views/practice/store'

const WD = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']

const read = <T,>(key: string, fallback: T): T => {
  try {
    const s = localStorage.getItem(key)
    return s !== null ? JSON.parse(s) : fallback
  } catch {
    return fallback
  }
}

interface DayStats {
  pct: number
  goalsDone: number
  cDone: number
  cTotal: number
  blockLabel: string
}

function getDayStats(): DayStats {
  const tk = todayKey()
  const now = new Date()
  const wdName = WD[now.getDay()]
  const lists = read<DayInstance[]>(`aod2-day-${tk}`, [])
  const goals = read<{ text: string; done: boolean }[]>(`aod2-goals-${tk}`, [])
  const sched = read<Record<string, boolean>>(`aod2-sched-${tk}`, {})

  const plan = WEEK_TEMPLATE.find((d) => d.day === wdName) ?? WEEK_TEMPLATE[0]
  const blocks = [...plan.blocks].sort((a, b) => a.time.localeCompare(b.time))

  const cTotal = lists.reduce((n, d) => n + d.items.length, 0)
  const cDone = lists.reduce((n, d) => n + d.items.filter((i) => i.done).length, 0)
  const gDone = goals.filter((g) => g.done).length
  const sDone = blocks.filter((_, i) => sched[`${wdName}-${i}`]).length
  const total = 4 + blocks.length + cTotal
  const done = gDone + sDone + cDone
  const pct = total ? Math.round((done / total) * 100) : 0

  const nowMin = now.getHours() * 60 + now.getMinutes()
  const short = (w: string) => w.split(/[·—]/)[0].trim().toLowerCase()
  let blockLabel = ''
  for (const b of blocks) {
    const [h, m] = b.time.split(':').map(Number)
    const t = h * 60 + m
    if (t <= nowMin && nowMin - t < 90) {
      blockLabel = `сейчас: ${short(b.what)}`
      break
    }
    if (t > nowMin) {
      blockLabel = `→ ${short(b.what)} ${b.time}`
      break
    }
  }

  return { pct, goalsDone: gDone, cDone, cTotal, blockLabel }
}

interface ClusterItem {
  view: ViewId
  label: string
  status: (s: DayStats) => string
}

interface Cluster {
  id: string
  label: string
  items: ClusterItem[]
}

const CLUSTERS: Cluster[] = [
  {
    id: 'today',
    label: 'Сегодня',
    items: [
      { view: 'day', label: 'День', status: (s) => `${s.pct}%` },
      {
        view: 'calendar',
        label: 'Календарь',
        status: () => {
          const custom = read<CalEvent[]>('aod-cal', [])
          const n = [...CAL_EVENTS, ...custom].filter((e) => e.date === todayKey()).length
          return n ? `${n} соб.` : 'нет событий'
        },
      },
      { view: 'checklists', label: 'Чек-листы', status: (s) => (s.cTotal ? `${s.cDone}/${s.cTotal}` : 'пусто') },
    ],
  },
  {
    id: 'notes',
    label: 'Записи',
    items: [
      { view: 'notes', label: 'Заметки', status: () => `${read<unknown[]>('aod2-notes', []).length} шт.` },
      {
        view: 'diary',
        label: 'Дневник',
        status: () => (read<Record<string, unknown>>('aod2-diary', {})[todayKey()] ? 'записано' : 'не записано'),
      },
      { view: 'blog', label: 'Блог', status: () => `${read<unknown[]>('aod2-blog', []).length} пост.` },
    ],
  },
  {
    id: 'system',
    label: 'Система',
    items: [
      { view: 'graph', label: 'Граф', status: () => 'v3.0' },
      {
        view: 'balance',
        label: 'Баланс',
        status: () => {
          const v = read<number[] | null>('aod-balance', null)
          if (!v || v.length !== 6) return 'нет оценки'
          const spread = Math.max(...v) - Math.min(...v)
          return spread <= 2 ? 'ровно' : `перекос ${spread}`
        },
      },
    ],
  },
  {
    id: 'path',
    label: 'Путь',
    items: [
      { view: 'roadmap', label: 'Роадмапа', status: () => 'Sprint 0' },
      { view: 'planning', label: 'Планирование', status: () => 'цикл 4 нед' },
    ],
  },
]

function MiniRing({ pct }: { pct: number }) {
  const r = 8
  const c = 2 * Math.PI * r
  return (
    <svg width="20" height="20" className="-rotate-90 flex-none">
      <circle cx="10" cy="10" r={r} fill="none" stroke="var(--line)" strokeWidth="2.5" />
      <circle
        cx="10" cy="10" r={r} fill="none" stroke="var(--accent)" strokeWidth="2.5"
        strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - pct / 100)}
        style={{ transition: 'stroke-dashoffset .5s ease' }}
      />
    </svg>
  )
}

export default function TopBar({ view, go }: { view: ViewId; go: (v: ViewId) => void }) {
  const [open, setOpen] = useState<string | null>(null)
  const [, setTick] = useState(0)
  const barRef = useRef<HTMLDivElement>(null)

  // обновляем статус раз в 20 сек + при смене экрана
  useEffect(() => {
    const t = setInterval(() => setTick((k) => k + 1), 20000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (barRef.current && !barRef.current.contains(e.target as Node)) setOpen(null)
    }
    document.addEventListener('click', close)
    return () => document.removeEventListener('click', close)
  }, [])

  const stats = useMemo(() => getDayStats(), [view])

  const activeCluster = (c: Cluster) => c.items.some((i) => i.view === view)

  return (
    <div ref={barRef} className="glass rounded-md flex items-center gap-1 px-3 py-2 relative">
      {/* logo */}
      <button
        onClick={() => go('hub')}
        className="flex items-center gap-2.5 pr-3 mr-1 flex-none"
        style={{ borderRight: '1px solid var(--line)' }}
      >
        <span
          className="grid place-items-center w-7 h-7 rounded-sm"
          style={{ background: 'var(--accent)', color: '#fff', fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600 }}
        >
          А
        </span>
        <span className="hidden sm:block leading-none text-left">
          <span className="display block" style={{ fontSize: 13 }}>Архитектор</span>
          <span className="mono-label" style={{ fontSize: 8, letterSpacing: '0.22em' }}>осознанного доверия</span>
        </span>
      </button>

      {/* clusters */}
      <nav className="flex items-center flex-1">
        {CLUSTERS.map((c) => (
          <div
            key={c.id}
            className="relative flex-none"
            onMouseEnter={() => setOpen(c.id)}
            onMouseLeave={() => setOpen((o) => (o === c.id ? null : o))}
          >
            <button
              className={`nav-item flex items-center gap-1 ${activeCluster(c) ? 'active' : ''}`}
              onClick={() => setOpen((o) => (o === c.id ? null : c.id))}
            >
              {c.label}
              <svg width="8" height="8" viewBox="0 0 12 12" fill="none"
                style={{ transform: open === c.id ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform .25s ease' }}>
                <path d="M2 4L6 8L10 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </button>
            {open === c.id && (
              <div
                className="fadein absolute left-0 top-full pt-2 z-50"
                style={{ minWidth: 230 }}
              >
                <div
                  className="rounded-md py-1.5"
                  style={{
                    background: 'rgba(22, 18, 16, 0.97)',
                    backdropFilter: 'blur(14px)',
                    WebkitBackdropFilter: 'blur(14px)',
                    border: '1px solid var(--line-strong)',
                    boxShadow: '0 16px 40px rgba(0,0,0,0.65)',
                  }}
                >
                  {c.items.map((i) => (
                    <button
                      key={i.view}
                      onClick={() => { go(i.view); setOpen(null) }}
                      className="w-full flex items-center justify-between gap-4 px-3.5 py-2.5 text-left transition-colors"
                      style={{
                        background: view === i.view ? 'rgba(36,116,255,0.10)' : 'transparent',
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(203,198,185,0.07)')}
                      onMouseLeave={(e) => (e.currentTarget.style.background = view === i.view ? 'rgba(36,116,255,0.10)' : 'transparent')}
                    >
                      <span className="text-[13px]" style={{ color: view === i.view ? 'var(--light)' : 'var(--text)' }}>
                        {i.label}
                      </span>
                      <span className="mono-label" style={{ fontSize: 8 }}>{i.status(stats)}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </nav>

      {/* live day status */}
      <button
        onClick={() => go('day')}
        className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-sm flex-none transition-colors hover:opacity-80"
        style={{ border: '1px solid var(--line)' }}
        title="Открыть «День»"
      >
        <MiniRing pct={stats.pct} />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--light)', whiteSpace: 'nowrap' }}>
          {stats.pct}%
          {stats.blockLabel ? ` · ${stats.blockLabel}` : ''} · {stats.goalsDone}/4
        </span>
      </button>

      <span className="mono-label hidden lg:block pl-3 flex-none" style={{ borderLeft: '1px solid var(--line)' }}>
        v3.0
      </span>
    </div>
  )
}
