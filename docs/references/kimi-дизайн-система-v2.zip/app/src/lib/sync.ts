import { useEffect, useRef, useState } from 'react'
import { trpc } from '@/providers/trpc'

// ─── движок синхронизации ───
// Каждый ключ живёт в трёх местах:
//   1. состояние React (мгновенный UI)
//   2. localStorage (мгновенный старт, офлайн-зеркало)
//   3. MySQL через tRPC (источник истины между устройствами)
// При первой загрузке: сервер пуст → локальные данные уезжают наверх (миграция),
// сервер полон → локальное состояние принимает серверное.

const readLS = <T,>(key: string, fallback: T): T => {
  try {
    const s = localStorage.getItem(key)
    return s !== null ? (JSON.parse(s) as T) : fallback
  } catch {
    return fallback
  }
}

const writeLS = (key: string, v: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(v))
  } catch {
    /* переполнение — не критично, сервер всё равно главный */
  }
}

const timers = new Map<string, ReturnType<typeof setTimeout>>()

export function useSyncedLS<T>(
  key: string,
  initial: T,
): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [v, setV] = useState<T>(() => readLS(key, initial))
  const initialRef = useRef(initial)
  const hydratedRef = useRef(false)

  const setMut = trpc.sync.set.useMutation()
  const mutRef = useRef(setMut.mutate)
  mutRef.current = setMut.mutate

  const q = trpc.sync.get.useQuery(
    { key },
    { staleTime: Infinity, retry: 1, refetchOnWindowFocus: false },
  )

  useEffect(() => {
    if (!q.data || hydratedRef.current) return
    hydratedRef.current = true
    const serverVal = q.data.value
    if (serverVal !== null && serverVal !== undefined) {
      // сервер — источник истины
      setV(serverVal as T)
      writeLS(key, serverVal)
    } else {
      // сервер пуст: мигрируем локальные данные (или сид) вверх
      const s = localStorage.getItem(key)
      const toPush = s !== null ? (JSON.parse(s) as T) : initialRef.current
      writeLS(key, toPush)
      mutRef.current({ key, value: toPush })
    }
  }, [q.data, key])

  const set: React.Dispatch<React.SetStateAction<T>> = (next) => {
    setV((prev) => {
      const value = typeof next === 'function' ? (next as (p: T) => T)(prev) : next
      writeLS(key, value)
      const t = timers.get(key)
      if (t) clearTimeout(t)
      timers.set(
        key,
        setTimeout(() => mutRef.current({ key, value }), 600),
      )
      return value
    })
  }

  return [v, set]
}
