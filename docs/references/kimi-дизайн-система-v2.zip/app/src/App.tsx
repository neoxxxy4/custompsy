import { useState, useCallback } from 'react';
import TopBar from '@/components/TopBar';
import Dashboard from '@/views/Dashboard';
import DayView from '@/views/DayView';
import GraphView from '@/views/GraphView';
import ChecklistsView from '@/views/ChecklistsView';
import BalanceView from '@/views/BalanceView';
import RoadmapView from '@/views/RoadmapView';
import PlanningView from '@/views/PlanningView';
import CalendarView from '@/views/CalendarView';
import BlogView from '@/views/BlogView';

export type ViewId =
  | 'hub' | 'day' | 'graph' | 'checklists' | 'notes' | 'diary'
  | 'balance' | 'roadmap' | 'planning' | 'calendar' | 'blog';

export const VIEW_TITLES: Record<ViewId, string> = {
  hub: 'Обзор',
  day: 'День',
  graph: 'Граф системы',
  checklists: 'Чек-листы',
  notes: 'Заметки',
  diary: 'Дневник',
  balance: 'Система баланса',
  roadmap: 'Роадмапа',
  planning: 'Планирование',
  calendar: 'Календарь',
  blog: 'Блог',
};

export default function App() {
  const [view, setView] = useState<ViewId>('hub');

  const go = useCallback((v: ViewId) => {
    setView(v);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <div className="min-h-screen relative" style={{ background: 'var(--bg)' }}>
      <div className="blueprint-bg" />
      <div className="vignette" />

      <div className="fixed top-3 inset-x-3 z-40 max-w-[1400px] mx-auto">
        <TopBar view={view} go={go} />
      </div>

      <main className="relative z-10 max-w-[1400px] mx-auto px-5 lg:px-8 pb-24 pt-8">
        {view === 'hub' && <Dashboard go={go} />}
        {view === 'day' && <DayView />}
        {view === 'graph' && <GraphView />}
        {(view === 'checklists' || view === 'notes' || view === 'diary') && (
          <ChecklistsView
            key={view}
            initialTab={view === 'notes' ? 'notes' : view === 'diary' ? 'diary' : 'lists'}
          />
        )}
        {view === 'balance' && <BalanceView />}
        {view === 'roadmap' && <RoadmapView />}
        {view === 'planning' && <PlanningView />}
        {view === 'calendar' && <CalendarView />}
        {view === 'blog' && <BlogView />}
      </main>

      <footer
        className="relative z-10 max-w-[1400px] mx-auto px-5 lg:px-8 pb-10 flex justify-between items-center"
      >
        <span className="mono-label">Архитектор осознанного доверия</span>
        <span className="mono-label">v1.0 «Гиперфокус» → v4.0 «Просветление»</span>
      </footer>
    </div>
  );
}
