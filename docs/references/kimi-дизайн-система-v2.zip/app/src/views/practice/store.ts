import type { Dispatch, SetStateAction } from 'react'
import { CHECKLISTS } from '../../data/system'

// ─── types ───

export interface TplItem { id: string; text: string; hint?: string }
export interface Template { id: string; title: string; time: string; color: string; items: TplItem[]; custom?: boolean }

export interface DayItem extends TplItem { done: boolean }
export interface DayInstance {
  iid: string
  templateId: string
  title: string
  time: string
  color: string
  collapsed: boolean
  items: DayItem[]
}

export interface Folder { id: string; name: string }
export interface Note { id: string; folderId: string; title: string; body: string; updated: number }

export interface DiaryEntry { text: string; emotion: string; focus: number; updated: number }
export type Diary = Record<string, DiaryEntry>

// ─── helpers ───

export const todayKey = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export const uid = () => Math.random().toString(36).slice(2, 9)

import { useSyncedLS } from '../../lib/sync'

export function useLS<T>(key: string, initial: T): [T, Dispatch<SetStateAction<T>>] {
  // хранилище переехало на сервер: localStorage остаётся зеркалом,
  // источник истины — MySQL (см. src/lib/sync.ts)
  return useSyncedLS(key, initial)
}

// все шаблоны: встроенные + пользовательские
export function allTemplates(custom: Template[]): Template[] {
  const builtin: Template[] = CHECKLISTS.map((c) => ({ ...c, custom: false }))
  return [...builtin, ...custom]
}

export function instantiate(t: Template): DayInstance {
  return {
    iid: uid(),
    templateId: t.id,
    title: t.title,
    time: t.time,
    color: t.color,
    collapsed: false,
    items: t.items.map((it) => ({ ...it, done: false })),
  }
}

// стартовый набор чек-листов дня (встроенные шаблоны)
export const seedDay = (): DayInstance[] => allTemplates([]).map(instantiate)

export const PALETTE = [
  'var(--f-discipline)',
  'var(--f-environment)',
  'var(--f-metacog)',
  'var(--f-emotions)',
  'var(--f-neuro)',
  'var(--f-boundaries)',
  '#e9e7e2',
  'var(--accent)',
]

export const PALETTE_HEX: Record<string, string> = {
  'var(--f-discipline)': '#efedbd',
  'var(--f-environment)': '#8ab2d1',
  'var(--f-metacog)': '#c6a1ce',
  'var(--f-emotions)': '#ffc09a',
  'var(--f-neuro)': '#aaf7b3',
  'var(--f-boundaries)': '#8ac1a0',
  '#e9e7e2': '#e9e7e2',
  'var(--accent)': '#2474ff',
}

// стартовые данные заметок
export const SEED_FOLDERS: Folder[] = [
  { id: 'inbox', name: 'Входящие' },
  { id: 'ideas', name: 'Идеи' },
  { id: 'thoughts', name: 'Выгрузка мыслей' },
]

export const SEED_NOTES: Note[] = [
  {
    id: 'welcome',
    folderId: 'inbox',
    title: 'Внешняя память',
    body: 'ОЗУ держит 7±2 объекта — всё остальное сюда.\n\nСоздавай папки слева, пиши заметки, ничего не держи в голове. Данные хранятся в этом браузере.',
    updated: Date.now(),
  },
]
