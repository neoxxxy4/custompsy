import { useMemo, useState } from 'react'
import {
  type Template,
  type DayInstance,
  allTemplates,
  instantiate,
  seedDay,
  todayKey,
  uid,
  useLS,
  PALETTE,
  PALETTE_HEX,
} from './store'

function Ring({ pct, color, size = 54 }: { pct: number; color: string; size?: number }) {
  const r = (size - 8) / 2
  const c = 2 * Math.PI * r
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--line)" strokeWidth="3" />
      <circle
        cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth="3"
        strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - pct)}
        style={{ transition: 'stroke-dashoffset .5s cubic-bezier(0.65,0,0.35,1)' }}
      />
    </svg>
  )
}

export default function ChecklistsTab() {
  const [day, setDay] = useLS<DayInstance[]>(`aod2-day-${todayKey()}`, seedDay())
  const [customTpls, setCustomTpls] = useLS<Template[]>('aod2-templates', [])
  const [pickerOpen, setPickerOpen] = useState(false)
  const [formOpen, setFormOpen] = useState(false)

  // форма нового шаблона
  const [fTitle, setFTitle] = useState('')
  const [fTime, setFTime] = useState('')
  const [fColor, setFColor] = useState(PALETTE[0])
  const [fItems, setFItems] = useState('')
  const [itemDrafts, setItemDrafts] = useState<Record<string, string>>({})

  const templates = useMemo(() => allTemplates(customTpls), [customTpls])
  const onDayIds = useMemo(() => new Set(day.map((d) => d.templateId)), [day])

  const total = day.reduce((n, d) => n + d.items.length, 0)
  const done = day.reduce((n, d) => n + d.items.filter((i) => i.done).length, 0)
  const dayPct = total ? done / total : 0

  const patch = (iid: string, fn: (d: DayInstance) => DayInstance) =>
    setDay((ds) => ds.map((d) => (d.iid === iid ? fn(d) : d)))

  const addToDay = (t: Template) => {
    if (onDayIds.has(t.id)) return
    setDay((ds) => [...ds, instantiate(t)])
  }

  const saveTemplate = () => {
    const items = fItems.split('\n').map((s) => s.trim()).filter(Boolean)
    if (!fTitle.trim() || items.length === 0) return
    const t: Template = {
      id: `custom-${uid()}`,
      title: fTitle.trim(),
      time: fTime.trim() || 'свой ритуал',
      color: fColor,
      items: items.map((text) => ({ id: uid(), text })),
      custom: true,
    }
    setCustomTpls((ts) => [...ts, t])
    setFTitle(''); setFTime(''); setFItems('')
    setFormOpen(false)
    setPickerOpen(true)
  }

  const resetMarks = () =>
    setDay((ds) => ds.map((d) => ({ ...d, items: d.items.map((i) => ({ ...i, done: false })) })))

  return (
    <div>
      {/* top bar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="relative">
            <Ring pct={dayPct} color="var(--accent)" size={64} />
            <span className="absolute inset-0 grid place-items-center"
              style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--light)' }}>
              {Math.round(dayPct * 100)}%
            </span>
          </div>
          <div>
            <p className="mono-label">Прогресс дня</p>
            <p className="display" style={{ fontSize: 22 }}>{done} / {total}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => { setPickerOpen((o) => !o); setFormOpen(false) }}
            className="mono-label-bright px-3 py-2 rounded-sm hover:opacity-85 transition-opacity"
            style={{ background: 'var(--accent)', color: '#fff' }}>
            + из шаблона
          </button>
          <button onClick={() => { setFormOpen((o) => !o); setPickerOpen(false) }}
            className="mono-label-bright px-3 py-2 rounded-sm glass hover:opacity-80 transition-opacity">
            + новый шаблон
          </button>
          <button onClick={resetMarks}
            className="mono-label px-3 py-2 rounded-sm glass hover:opacity-80 transition-opacity">
            сброс отметок
          </button>
        </div>
      </div>

      {/* template picker */}
      {pickerOpen && (
        <div className="fadein panel rounded-md p-5 mt-4">
          <p className="mono-label mb-3">Заготовленные шаблоны · добавляются копией, шаблон не меняется</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {templates.map((t) => {
              const added = onDayIds.has(t.id)
              return (
                <div key={t.id} className="flex items-center gap-3 rounded-sm px-3 py-2.5"
                  style={{ border: '1px solid var(--line)', opacity: added ? 0.45 : 1 }}>
                  <span className="tag-dot" style={{ background: t.color }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] truncate" style={{ color: 'var(--light)' }}>{t.title}</p>
                    <p className="mono-label" style={{ fontSize: 8 }}>{t.items.length} пунктов{t.custom ? ' · свой' : ''}</p>
                  </div>
                  {added ? (
                    <span className="mono-label" style={{ fontSize: 8 }}>в дне</span>
                  ) : (
                    <button onClick={() => addToDay(t)}
                      className="mono-label-bright px-2 py-1 rounded-sm hover:opacity-80"
                      style={{ border: '1px solid var(--accent)', color: 'var(--accent)', fontSize: 9 }}>
                      + в день
                    </button>
                  )}
                  {t.custom && (
                    <button
                      onClick={() => {
                        if (window.confirm(`Удалить шаблон «${t.title}»? Списки дня не пострадают.`))
                          setCustomTpls((ts) => ts.filter((x) => x.id !== t.id))
                      }}
                      className="mono-label hover:opacity-60 px-1" title="Удалить шаблон">✕</button>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* new template form */}
      {formOpen && (
        <div className="fadein panel rounded-md p-5 mt-4">
          <p className="mono-label mb-3">Новый шаблон · останется в заготовках навсегда</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <input value={fTitle} onChange={(e) => setFTitle(e.target.value)} placeholder="Название · например, Тренировка"
                className="w-full bg-transparent rounded-sm px-3 py-2 text-[13px] outline-none mb-2"
                style={{ border: '1px solid var(--line-strong)', color: 'var(--light)' }} />
              <input value={fTime} onChange={(e) => setFTime(e.target.value)} placeholder="Подпись · например, 3 раза в неделю"
                className="w-full bg-transparent rounded-sm px-3 py-2 text-[13px] outline-none mb-3"
                style={{ border: '1px solid var(--line-strong)', color: 'var(--light)' }} />
              <p className="mono-label mb-2">Цвет</p>
              <div className="flex gap-2">
                {PALETTE.map((c) => (
                  <button key={c} onClick={() => setFColor(c)}
                    className="w-6 h-6 rounded-full transition-transform"
                    style={{
                      background: PALETTE_HEX[c],
                      transform: fColor === c ? 'scale(1.25)' : 'scale(1)',
                      boxShadow: fColor === c ? `0 0 0 2px var(--bg), 0 0 0 3px ${PALETTE_HEX[c]}` : 'none',
                    }} />
                ))}
              </div>
            </div>
            <div>
              <textarea value={fItems} onChange={(e) => setFItems(e.target.value)}
                placeholder={'Пункты — каждый с новой строки:\nРазминка 10 мин\nОсновная часть\nЗаминка и растяжка'}
                rows={5}
                className="w-full bg-transparent rounded-sm px-3 py-2 text-[13px] outline-none resize-y"
                style={{ border: '1px solid var(--line-strong)', color: 'var(--light)', fontFamily: 'var(--font-body)' }} />
              <button onClick={saveTemplate}
                className="mt-2 mono-label-bright px-4 py-2 rounded-sm hover:opacity-85 transition-opacity"
                style={{ background: 'var(--accent)', color: '#fff' }}>
                Сохранить шаблон
              </button>
            </div>
          </div>
        </div>
      )}

      {/* day lists */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-3 items-start">
        {day.length === 0 && (
          <div className="panel rounded-md p-8 text-center md:col-span-2">
            <p className="mono-label" style={{ lineHeight: 2 }}>День пуст. Добавь чек-листы из шаблонов.</p>
          </div>
        )}
        {day.map((inst) => {
          const dDone = inst.items.filter((i) => i.done).length
          return (
            <section key={inst.iid} className="panel rounded-md overflow-hidden">
              <header
                className="flex items-center gap-3 px-5 py-4 cursor-pointer select-none"
                onClick={() => patch(inst.iid, (d) => ({ ...d, collapsed: !d.collapsed }))}
              >
                <span className="tag-dot" style={{ background: inst.color }} />
                <div className="flex-1 min-w-0">
                  <h3 className="display truncate" style={{ fontSize: 19 }}>{inst.title}</h3>
                  <p className="mono-label" style={{ fontSize: 8 }}>{inst.time}</p>
                </div>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)' }}>
                  {dDone}/{inst.items.length}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    setDay((ds) => ds.filter((d) => d.iid !== inst.iid))
                  }}
                  className="mono-label hover:opacity-60 px-1.5" title="Убрать из дня (шаблон останется)">✕</button>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none"
                  style={{ transform: inst.collapsed ? 'rotate(-90deg)' : 'rotate(0deg)', transition: 'transform .3s ease' }}>
                  <path d="M2 4L6 8L10 4" stroke="var(--muted)" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
              </header>
              <div
                style={{
                  display: 'grid',
                  gridTemplateRows: inst.collapsed ? '0fr' : '1fr',
                  transition: 'grid-template-rows .35s cubic-bezier(0.65,0,0.35,1)',
                }}
              >
                <div style={{ overflow: 'hidden' }}>
                  <div className="px-5 pb-4" style={{ borderTop: '1px solid var(--line)' }}>
                    {inst.items.map((it) => (
                      <div key={it.id}
                        className={`check-row group ${it.done ? 'done' : ''}`}
                        style={{ ['--row-color' as string]: inst.color }}
                        onClick={() =>
                          patch(inst.iid, (d) => ({
                            ...d,
                            items: d.items.map((x) => (x.id === it.id ? { ...x, done: !x.done } : x)),
                          }))
                        }>
                        <span className="box">
                          <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                            <path d="M1.5 5.5L4 8L8.5 2" stroke="#050100" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                        </span>
                        <span className="flex-1">
                          <span className="label block text-[13.5px] leading-snug" style={{ color: 'var(--light)' }}>{it.text}</span>
                          {it.hint && <span className="block mt-0.5 text-[11.5px]" style={{ color: 'var(--muted)' }}>{it.hint}</span>}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            patch(inst.iid, (d) => ({ ...d, items: d.items.filter((x) => x.id !== it.id) }))
                          }}
                          className="mono-label opacity-0 group-hover:opacity-100 hover:!opacity-60 transition-opacity px-1"
                          title="Убрать пункт из дня">✕</button>
                      </div>
                    ))}
                    {/* add item */}
                    <div className="flex gap-2 mt-3">
                      <input
                        value={itemDrafts[inst.iid] || ''}
                        onChange={(e) => setItemDrafts((s) => ({ ...s, [inst.iid]: e.target.value }))}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && (itemDrafts[inst.iid] || '').trim()) {
                            patch(inst.iid, (d) => ({
                              ...d,
                              items: [...d.items, { id: uid(), text: itemDrafts[inst.iid].trim(), done: false }],
                            }))
                            setItemDrafts((s) => ({ ...s, [inst.iid]: '' }))
                          }
                        }}
                        placeholder="+ пункт только на сегодня"
                        className="flex-1 bg-transparent rounded-sm px-3 py-1.5 text-[12.5px] outline-none"
                        style={{ border: '1px dashed var(--line-strong)', color: 'var(--light)' }} />
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )
        })}
      </div>

      <p className="mono-label mt-5" style={{ fontSize: 8 }}>
        Отметки и правки живут только в копии дня и обнуляются завтра · шаблоны не меняются
      </p>
    </div>
  )
}
