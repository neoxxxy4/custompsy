import { useMemo } from 'react'
import { WEEK_TEMPLATE, CAL_EVENTS, type CalEvent } from '../data/system'
import { type DayInstance, seedDay, todayKey, useLS } from './practice/store'

const WD = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']
const MO = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря']

interface Goal { text: string; done: boolean }
const EMPTY_GOALS: Goal[] = Array.from({ length: 4 }, () => ({ text: '', done: false }))

function Ring({ pct, color, size = 76 }: { pct: number; color: string; size?: number }) {
  const r = (size - 8) / 2
  const c = 2 * Math.PI * r
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--line)" strokeWidth="4" />
      <circle
        cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth="4"
        strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - pct)}
        style={{ transition: 'stroke-dashoffset .5s cubic-bezier(0.65,0,0.35,1)' }}
      />
    </svg>
  )
}

function Tick({ done, color, size = 16 }: { done: boolean; color: string; size?: number }) {
  return (
    <span
      className="grid place-items-center rounded-sm flex-none transition-all"
      style={{
        width: size, height: size,
        border: `1px solid ${done ? color : 'var(--line-strong)'}`,
        background: done ? color : 'transparent',
      }}
    >
      <svg width={size * 0.62} height={size * 0.62} viewBox="0 0 10 10" fill="none"
        style={{ opacity: done ? 1 : 0, transition: 'opacity .15s ease' }}>
        <path d="M1.5 5.5L4 8L8.5 2" stroke="#050100" strokeWidth="2" strokeLinecap="round" />
      </svg>
    </span>
  )
}

export default function DayView() {
  const now = new Date()
  const wdName = WD[now.getDay()]
  const dateLabel = `${now.getDate()} ${MO[now.getMonth()]} · ${['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота'][now.getDay()]}`

  // те же ключи localStorage, что и в других модулях — галочки синхронизируются
  const [dayLists, setDayLists] = useLS<DayInstance[]>(`aod2-day-${todayKey()}`, seedDay())
  const [goals, setGoals] = useLS<Goal[]>(`aod2-goals-${todayKey()}`, EMPTY_GOALS)
  const [schedDone, setSchedDone] = useLS<Record<string, boolean>>(`aod2-sched-${todayKey()}`, {})
  const [customEvents] = useLS<CalEvent[]>('aod-cal', [])

  // расписание из «Планирования»
  const plan = WEEK_TEMPLATE.find((d) => d.day === wdName) ?? WEEK_TEMPLATE[0]
  const blocks = useMemo(
    () => [...plan.blocks].sort((a, b) => a.time.localeCompare(b.time)),
    [plan]
  )

  // события из «Календаря»
  const eventsToday = useMemo(
    () => [...CAL_EVENTS, ...customEvents].filter((e) => e.date === todayKey()),
    [customEvents]
  )

  // прогресс дня: цели + блоки расписания + пункты чек-листов
  const stats = useMemo(() => {
    const g = goals.filter((x) => x.done).length
    const s = blocks.filter((_, i) => schedDone[`${wdName}-${i}`]).length
    const cTotal = dayLists.reduce((n, d) => n + d.items.length, 0)
    const cDone = dayLists.reduce((n, d) => n + d.items.filter((i) => i.done).length, 0)
    const total = 4 + blocks.length + cTotal
    const done = g + s + cDone
    return { total, done, pct: total ? done / total : 0 }
  }, [goals, blocks, schedDone, dayLists, wdName])

  const toggleGoal = (i: number) =>
    setGoals((gs) => gs.map((g, j) => (j === i ? { ...g, done: !g.done } : g)))
  const setGoalText = (i: number, text: string) =>
    setGoals((gs) => gs.map((g, j) => (j === i ? { ...g, text } : g)))

  return (
    <div className="max-w-5xl mx-auto px-6 pt-28 pb-10">
      {/* header */}
      <div className="rise flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="mono-label mb-2">Модуль 01 · собрано из Практики, Планирования и Календаря</p>
          <h2 className="display" style={{ fontSize: 'clamp(36px, 5vw, 64px)' }}>Сегодня</h2>
          <p className="mono-label mt-2">{dateLabel}</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Ring pct={stats.pct} color="var(--accent)" />
            <span className="absolute inset-0 grid place-items-center"
              style={{ fontFamily: 'var(--font-mono)', fontSize: 14, color: 'var(--light)' }}>
              {Math.round(stats.pct * 100)}%
            </span>
          </div>
          <div>
            <p className="mono-label">Прогресс дня</p>
            <p className="display" style={{ fontSize: 26 }}>{stats.done} / {stats.total}</p>
          </div>
        </div>
      </div>

      {/* events from calendar */}
      {eventsToday.length > 0 && (
        <div className="rise mt-8 flex flex-wrap gap-2" style={{ animationDelay: '60ms' }}>
          {eventsToday.map((e, i) => (
            <span key={i} className="flex items-center gap-2 px-3 py-2 rounded-sm glass">
              <span className="tag-dot" style={{ background: e.color }} />
              <span className="text-[12.5px]" style={{ color: 'var(--light)' }}>{e.title}</span>
              <span className="mono-label" style={{ fontSize: 8 }}>{e.kind}</span>
            </span>
          ))}
        </div>
      )}

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-3 items-start">
        <div className="space-y-3">
          {/* goals */}
          <section className="rise panel rounded-md p-6" style={{ animationDelay: '100ms' }}>
            <div className="flex items-baseline justify-between mb-4">
              <p className="mono-label">Главные цели дня · 4 штуки</p>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)' }}>
                {goals.filter((g) => g.done).length}/4
              </span>
            </div>
            {goals.map((g, i) => (
              <div key={i} className="flex items-center gap-4 py-3"
                style={{ borderBottom: i < 3 ? '1px dashed var(--line)' : 'none' }}>
                <span className="display" style={{ fontSize: 24, color: g.done ? 'var(--accent)' : 'var(--line-strong)', width: 34 }}>
                  {String(i + 1).padStart(2, '0')}
                </span>
                <button onClick={() => toggleGoal(i)} className="flex-none">
                  <Tick done={g.done} color="var(--accent)" size={18} />
                </button>
                <input
                  value={g.text}
                  onChange={(e) => setGoalText(i, e.target.value)}
                  placeholder={`Цель №${i + 1} — что обязательно сделаю сегодня`}
                  className="flex-1 bg-transparent outline-none text-[14px]"
                  style={{
                    color: g.done ? 'var(--muted)' : 'var(--light)',
                    textDecoration: g.done ? 'line-through' : 'none',
                    textDecorationColor: 'var(--line-strong)',
                  }}
                />
              </div>
            ))}
          </section>

          {/* schedule */}
          <section className="rise panel rounded-md p-6" style={{ animationDelay: '160ms' }}>
            <div className="flex items-baseline justify-between mb-4">
              <p className="mono-label">Расписание · шаблон {plan.day} из «Планирования»</p>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)' }}>
                {blocks.filter((_, i) => schedDone[`${wdName}-${i}`]).length}/{blocks.length}
              </span>
            </div>
            <div className="relative pl-6">
              <div className="absolute left-[5px] top-2 bottom-2 w-px" style={{ background: 'var(--line)' }} />
              {blocks.map((b, i) => {
                const key = `${wdName}-${i}`
                const done = !!schedDone[key]
                return (
                  <div key={key}
                    className="relative flex items-center gap-4 py-2.5 cursor-pointer group"
                    onClick={() => setSchedDone((s) => ({ ...s, [key]: !s[key] }))}>
                    <span className="absolute -left-6 top-1/2 -translate-y-1/2 w-[11px] h-[11px] rounded-full transition-all"
                      style={{
                        background: done ? (b.color ?? 'var(--accent)') : 'var(--bg)',
                        border: `2px solid ${b.color ?? 'var(--line-strong)'}`,
                      }} />
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: done ? 'var(--muted)' : (b.color ?? 'var(--accent)'), width: 44 }}>
                      {b.time}
                    </span>
                    <Tick done={done} color={b.color ?? 'var(--accent)'} />
                    <span className="text-[13.5px] transition-colors"
                      style={{
                        color: done ? 'var(--muted)' : 'var(--light)',
                        textDecoration: done ? 'line-through' : 'none',
                        textDecorationColor: 'var(--line-strong)',
                      }}>
                      {b.what}
                    </span>
                  </div>
                )
              })}
            </div>
          </section>
        </div>

        {/* checklists of the day */}
        <aside className="rise space-y-3" style={{ animationDelay: '220ms' }}>
          <p className="mono-label px-1">Чек-листы дня · синхронно с «Практикой»</p>
          {dayLists.length === 0 && (
            <div className="panel rounded-md p-6">
              <p className="mono-label" style={{ lineHeight: 2 }}>Нет списков. Добавь в «Практике» → «+ из шаблона».</p>
            </div>
          )}
          {dayLists.map((inst) => {
            const dDone = inst.items.filter((i) => i.done).length
            return (
              <section key={inst.iid} className="panel rounded-md overflow-hidden">
                <header
                  className="flex items-center gap-2.5 px-4 py-3 cursor-pointer select-none"
                  onClick={() =>
                    setDayLists((ds) => ds.map((d) => (d.iid === inst.iid ? { ...d, collapsed: !d.collapsed } : d)))
                  }>
                  <span className="tag-dot" style={{ background: inst.color }} />
                  <h3 className="display flex-1 truncate" style={{ fontSize: 16 }}>{inst.title}</h3>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--muted)' }}>
                    {dDone}/{inst.items.length}
                  </span>
                  <svg width="10" height="10" viewBox="0 0 12 12" fill="none"
                    style={{ transform: inst.collapsed ? 'rotate(-90deg)' : 'rotate(0deg)', transition: 'transform .3s ease' }}>
                    <path d="M2 4L6 8L10 4" stroke="var(--muted)" strokeWidth="1.5" strokeLinecap="round" />
                  </svg>
                </header>
                <div style={{
                  display: 'grid',
                  gridTemplateRows: inst.collapsed ? '0fr' : '1fr',
                  transition: 'grid-template-rows .35s cubic-bezier(0.65,0,0.35,1)',
                }}>
                  <div style={{ overflow: 'hidden' }}>
                    <div className="px-4 pb-3" style={{ borderTop: '1px solid var(--line)' }}>
                      {inst.items.map((it) => (
                        <div key={it.id}
                          className="flex items-start gap-2.5 py-2 cursor-pointer"
                          style={{ borderBottom: '1px dashed var(--line)' }}
                          onClick={() =>
                            setDayLists((ds) =>
                              ds.map((d) =>
                                d.iid === inst.iid
                                  ? { ...d, items: d.items.map((x) => (x.id === it.id ? { ...x, done: !x.done } : x)) }
                                  : d
                              )
                            )
                          }>
                          <Tick done={it.done} color={inst.color} size={14} />
                          <span className="text-[12.5px] leading-snug"
                            style={{
                              color: it.done ? 'var(--muted)' : 'var(--light)',
                              textDecoration: it.done ? 'line-through' : 'none',
                              textDecorationColor: 'var(--line-strong)',
                            }}>
                            {it.text}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </section>
            )
          })}
        </aside>
      </div>
    </div>
  )
}
